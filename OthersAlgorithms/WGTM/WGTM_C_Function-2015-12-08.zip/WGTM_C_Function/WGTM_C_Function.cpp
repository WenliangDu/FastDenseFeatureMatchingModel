// WGTM_C_Function.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include<string>
using namespace std;
void GTM(double **P1,double **P2,int N, int K, double outliers[]);
void WGTM(double **P1,double **P2,int N, int K,double ebs, double outliers[]);
void createKNNGraph_WGTM(double dist[],int N, int K,double medianDist, double G[]);
void createKNNGraph_GTM(double dist[],int N, int K,double medianDist, double G[]);
void createWeightedGraph(double G1[],double G2[],int N,double **P1,double **P2,int ind[], int Nind, double G3[]);
void getAngularDistance(double **r1,double **r2,int N, double t[]);
void copyArr(double arr1[],double arr2[], int N);
void sumArr2(double arr1[], int N,double arr2[],int horz);
void maxArr(double arr1[], int N,double *m,int *ind);
void minArr(double arr1[], int N,double *m,int *ind);
void maxArr2(double arr1[], int N,double arr2[],int horz);
int IsMember( int arr[], int N,int item );
void findIndex(double x[],int N,int y[], int *Ny);
void createKNNGraph_fast(double dist[],int N, int K,double medianDist, double G[],int ind[],int Nind );
void createKNNGraph_fast_WGTM(double dist[],int N, int K,double medianDist, double G[],int ind[],int Nind );
void createKNNGraph_fast_GTM(double dist[],int N, int K,double medianDist, double G[],int ind[],int &Nind );
void selectionSort ( double arr[], int size);
void swap ( double *x, double *y ); 

int _tmain(int argc, _TCHAR* argv[])
{

	
	ifstream in("input.txt");
	ofstream out("output.txt");
	if (!in.is_open())
	{
		printf( "The file 'data' was not opened\n" );
	}else
	{
		double ebs,*outliers,**P1,**P2 ;
		double K,N;
		int i;


//		in>>N>>K>>ebs;
		in>>N>>K; 
	    
		P1 = (double**)calloc(N,sizeof(double*));
		P2 = (double**)calloc(N,sizeof(double*));
		for(i=0;i<N;i++)
		{
			P1[i]=(double*)calloc(2,sizeof(double));

			P2[i]=(double*)calloc(2,sizeof(double));
		}
		for(i=0;i<N;i++)
		{
			in>>P1[i][0]>>P1[i][1];
		}
		for(i=0;i<N;i++)
		{
			in>>P2[i][0]>>P2[i][1];
		}
		
		
		outliers = (double*)calloc(N,sizeof(double));
		
//				clock_t t1,t2;
//				float diff;
//		WGTM(P1,P2,N,K,ebs,outliers);
//t1=clock();
		GTM(P1,P2,N,K,outliers);
//		t2=clock();
//		diff = double(t2-t1)/CLOCKS_PER_SEC;
//		cout<<diff;
		for(i=0;i<N;i++)
		{
			out<<outliers[i]<<endl;
		}

		free(outliers);

		for(i=0;i<N;i++)
		{
			free(P1[i]);
			free(P2[i]);
		}
		free(P1);
		free(P2);


	}
	in.close();
	out.close();
	return 0;
}

//GTM
void GTM(double **P1,double **P2,int N, int K, double outliers[])
{
	double *dist1,*dist2,*dist3,medianDist1,medianDist2;

	int i,j,ii,jj,e,num=0,*index,Nind=0,*index2,Nind2=0,*index1,Nind1=0;
	double *G1,*G2,*R,*temp,*x1,*x2;

	dist1 = (double*)calloc(N*N,sizeof(double));
	dist2 = (double*)calloc(N*N,sizeof(double));
	dist3 = (double*)calloc(N*N,sizeof(double));
	G1 = (double*)calloc(N*N,sizeof(double));
	G2 = (double*)calloc(N*N,sizeof(double));
	R = (double*)calloc(N*N,sizeof(double));
	temp = (double*)calloc(N*N,sizeof(double));
	x1 = (double*)calloc(N,sizeof(double));
	x2 = (double*)calloc(N,sizeof(double));
	index1 = (int*)calloc(N,sizeof(int));
	index = (int*)calloc(N,sizeof(int));
	index2 = (int*)calloc(N,sizeof(int));
	
	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			dist1[i*N+j]=sqrt((P1[i][0]-P1[j][0])*(P1[i][0]-P1[j][0])+(P1[i][1]-P1[j][1])*(P1[i][1]-P1[j][1]));
			dist2[i*N+j]=sqrt((P2[i][0]-P2[j][0])*(P2[i][0]-P2[j][0])+(P2[i][1]-P2[j][1])*(P2[i][1]-P2[j][1]));

		}
		outliers[i]=0;
	}
	 
	// median distance
	copyArr(dist1,dist3,N*N);
	sort(dist3,dist3+N*N);
//	selectionSort(dist3,N*N);
	medianDist1=dist3[(N*N/2)];


	copyArr(dist2,dist3,N*N);
	sort(dist3,dist3+N*N);
//	selectionSort(dist3,N*N);
	medianDist2=dist3[(N*N/2)];


	// GTM


	createKNNGraph_GTM(dist1,N,K,medianDist1,G1);
	createKNNGraph_GTM(dist2,N,K,medianDist2,G2);
	e=0;
	for (i=0;i<N*N;i++)
	{
		if (G1[i]!=G2[i])
			e=1;
	}

	for (i=0;i<N*N;i++)
	{
			R[i]=abs(G1[i]-G2[i]);			
	}

	while (e>0)
	{
		int ind=0;
		double m=0;

		sumArr2(R,N,temp,1);
		maxArr(temp,N,&m,&ind);
		if(m!=0)
		{
		outliers[ind]=1;
/*		Nind1=0;
		Nind2=0;
			for (i=0;i<N;i++)
			x1[i]=G1[61*N+i];
		findIndex(x1,N,index1,&Nind1);
		for (i=0;i<N;i++)
			x2[i]=R[61*N+i];
		findIndex(x2,N,index2,&Nind2);

		if(ind==61)
			ind=ind;*/
		for (i=0;i<N;i++)
		{
			x1[i]=G1[i*N+ind]+G1[ind*N+i];
			x2[i]=G2[i*N+ind]+G2[ind*N+i];

			G1[ind*N+i]=0;
			G1[ind+i*N]=0;
			G2[ind*N+i]=0;
			G2[ind+i*N]=0;
			dist1[ind*N+i]=medianDist1+1;
			dist1[ind+i*N]=medianDist1+1;
			dist2[ind*N+i]=medianDist2+1;
			dist2[ind+i*N]=medianDist2+1;
		}

		Nind1=0;
		findIndex(x1,N,index1,&Nind1);
		
		createKNNGraph_fast_GTM(dist1,N,K,medianDist1,G1,index1,Nind1);
		Nind2=0;
		findIndex(x2,N,index2,&Nind2);
		createKNNGraph_fast_GTM(dist2,N,K,medianDist2,G2,index2,Nind2);
//	createKNNGraph_GTM(dist1,N,K,medianDist1,G1);
//	createKNNGraph_GTM(dist2,N,K,medianDist2,G2);
		for (ii=0;ii<Nind1;ii++)
		{
			
			for (jj=0;jj<N;jj++)
		{

			R[index1[ii]*N+jj]=abs(G1[index1[ii]*N+jj]-G2[index1[ii]*N+jj]);
			R[index1[ii]+jj*N]=R[index1[ii]*N+jj];
			}
		}
		for (ii=0;ii<Nind2;ii++)
		{
			
			for (jj=0;jj<N;jj++)
		{

			R[index2[ii]*N+jj]=abs(G1[index2[ii]*N+jj]-G2[index2[ii]*N+jj]);
			R[index2[ii]+jj*N]=R[index2[ii]*N+jj];
			}
		}
/*		for (i=0;i<N*N;i++)
	{
			R[i]=abs(G1[i]-G2[i]);			
	}
*/	

		e=0;
		num++;
//		cout<<num<<endl;
//		if(num==40)
//			num=num;
/*		for (i=0;i<N*N;i++)
		{
			if (G1[i]!=G2[i])
				e=1;
		}*/
//		if((Nind1+Nind2)>0)
//			e=1;
		if (num>(N+2))
			e=0;
		else
			e=1;
		}else
		{
			e=0;
		}
	}
//		cout<<num++<<endl;
 		sumArr2(G1,N,x1,0);
		
		for (i=0;i<N;i++)
		{
			if (x1[i]<K)
			{
				outliers[i]=1;
			}else
				outliers[i]=0;
			
		}

	free(dist1);
	free(dist2);
	free(dist3);
	free(G1);
	free(G2);
	free(R);
	free(temp);
	free (x1);
	free(x2);
	free(index1);
	free(index);
	free(index2);
}
//WGTM
void WGTM(double **P1,double **P2,int N, int K,double ebs, double outliers[])
{
	double angDist,s,*dist1,*dist2,*dist3,*x,*x1,*x2,medianDist1,medianDist2;

	int i,j,ii,k,n,n3,nx1,e,*ind,*ind1,num=0,*index,Nind,j1,j2;
	double *G1,*G2,*G11,*G22,*G3,*temp;
	double mu1=4,mu2=0;

	dist1 = (double*)calloc(N*N,sizeof(double));
	dist2 = (double*)calloc(N*N,sizeof(double));
	dist3 = (double*)calloc(N*N,sizeof(double));
	G1 = (double*)calloc(N*N,sizeof(double));
	G2 = (double*)calloc(N*N,sizeof(double));
	G11 = (double*)calloc(N*N,sizeof(double));
	G22 = (double*)calloc(N*N,sizeof(double));
	G3 = (double*)calloc(N*N,sizeof(double));
	temp = (double*)calloc(N*N,sizeof(double));
	x = (double*)calloc(N,sizeof(double));
	x1 = (double*)calloc(N,sizeof(double));
	x2 = (double*)calloc(N,sizeof(double));
	ind = (int*)calloc(N,sizeof(int));
	index = (int*)calloc(N,sizeof(int));
	ind1 = (int*)calloc(N,sizeof(int));
	

	for (i=0;i<N;i++)
	{
		ind[i]=i;
		for (j=0;j<N;j++)
		{
			dist1[i*N+j]=sqrt((P1[i][0]-P1[j][0])*(P1[i][0]-P1[j][0])+(P1[i][1]-P1[j][1])*(P1[i][1]-P1[j][1]));
			dist2[i*N+j]=sqrt((P2[i][0]-P2[j][0])*(P2[i][0]-P2[j][0])+(P2[i][1]-P2[j][1])*(P2[i][1]-P2[j][1]));

		}
		outliers[i]=0;
	}
	 
	// median distance
	copyArr(dist1,dist3,N*N);
	sort(dist3,dist3+N*N);
//	selectionSort(dist3,N*N);
	medianDist1=dist3[(N*N/2)];

	copyArr(dist2,dist3,N*N);
	sort(dist3,dist3+N*N);
//	selectionSort(dist3,N*N);
	medianDist2=dist3[(N*N/2)];



	// WGTM


	createKNNGraph_WGTM(dist1,N,K,medianDist1,G1);
	createKNNGraph_WGTM(dist2,N,K,medianDist2,G2);
	for (i=0;i<N*N;i++)
		G3[i]=-1;
	createWeightedGraph(G1,G2,N,P1,P2,ind,N,G3);
	/*
	double v[2];
	n=0;
	for (i=0;i<N*N;i++)
		if(G3[i]>=0)
			temp[n++]=G3[i];
	Fuzzy_C_Means(temp,n,2,v,1000);
	nx1=0;
	if (v[0]>v[1])
		swap(v[0],v[1]);
	s=0;
	for (i=0;i<n;i++)
	{
		if (sqrt((v[0]-temp[i])*(v[0]-temp[i]))<sqrt((v[1]-temp[i])*(v[1]-temp[i])))
		{
			dist3[nx1++]=temp[i];
			s+=temp[i];
		}
	}
	angDist=s/nx1;

	
	s=0;
	for (i=0;i<nx1;i++)
	{
		s+=(dist3[i]-angDist)*(dist3[i]-angDist);
	}
	s=sqrt(s/nx1);
	angDist=angDist+2.5*s;*/
	
	angDist=3.14/2;
	e=0;
	for (i=0;i<N;i++)
		x[i]=-1;
	mu1=0;
	n3=0;
	for (i=0;i<N;i++)
	{
		s=0;
		
		n=0;
		for (j=0;j<N;j++)
		{
			if (G3[i*N+j]>=0)
			{					
				s+=G3[i*N+j];
				n++;
			}


		}
		if (n>0)
		{
			x[i]=s/n;
			mu1+=x[i];
			n3++;
		}else
			x[i]=-1;
	}
	mu1=mu1/n3;
	
	while (e==0)
	{
		maxArr2(G3,N,temp,1);
		n=0;
		for (i=0;i<N;i++)
			if (temp[i]<0)
				ind[i]=1;
			else
				ind[i]=0;

		sumArr2(G1,N,x1,0);
		sumArr2(G1,N,x2,1);
		for (i=0;i<N;i++)
		{
			if (x1[i]<=2 && x2[i]<=2 )
			{
				ind[i]=1;
			}
			if (outliers[i]!=0)
				ind[i]=0;
		}
		n=0;
		for (i=0;i<N;i++)
			if (ind[i]==1)
				ind1[n++]=i;

		if (n>0)
		{
			for (i=0;i<n;i++)
			{
				outliers[ind1[i]]=1;
				for (j=0;j<N;j++)
				{
					dist1[ind1[i]*N+j]=medianDist1+1;
					dist1[ind1[i]+j*N]=medianDist1+1;
					dist2[ind1[i]*N+j]=medianDist2+1;
					dist2[ind1[i]+j*N]=medianDist2+1;
				}
			}
			copyArr(G1,G11,N*N);
			copyArr(G2,G22,N*N);
			createKNNGraph_WGTM(dist1,N,K,medianDist1,G1);
			createKNNGraph_WGTM(dist2,N,K,medianDist2,G2);
			n=0;
			for (i=0;i<N;i++)
			{
				s=0;
				
				for (j=0;j<N;j++)
				{
					j1=(G1[i*N+j]+G11[i*N+j]);
					j2=(G2[i*N+j]+G22[i*N+j]);
					s+=(j1%2)+(j2%2)	;				
				}
				if(s>0)
					ind[n++]=i;
			}
			
			
			createWeightedGraph(G1,G2,N,P1,P2,ind,n,G3);
			mu2=5;
			
		}else
		{
			for (i=0;i<N;i++)
				x[i]=-1;
			mu2=0;
			n3=0;
			for (i=0;i<N;i++)
			{
				s=0;
				
				n=0;
				for (j=0;j<N;j++)
				{
					if (G3[i*N+j]>=0)
					{					
						s+=G3[i*N+j];
						n++;
					}


				}
				if (n>0)
				{
					x[i]=s/n;
					mu2+=x[i];
					n3++;
				}else
					x[i]=-1;
			}
			
			maxArr(x,N,&s,&k);
			mu2=(mu2-s)/(n3-1);

			outliers[k]=1;

			for (j=0;j<N;j++)
			{
				x1[j]=G1[j*N+k];
				x2[j]=G2[j*N+k];

				G1[k*N+j]=0;
				G1[k+j*N]=0;
				G2[k*N+j]=0;
				G2[k+j*N]=0;
				G3[k*N+j]=-1;
				G3[k+j*N]=-1;

				dist1[k*N+j]=medianDist1+1;
				dist1[k+j*N]=medianDist1+1;
				dist2[k*N+j]=medianDist2+1;
				dist2[k+j*N]=medianDist2+1;
			}
			Nind=0;
			findIndex(x1,N,index,&Nind);
			createKNNGraph_fast_WGTM(dist1,N,K,medianDist1,G1,index,Nind);
			Nind=0;
			findIndex(x2,N,index,&Nind);
			createKNNGraph_fast_WGTM(dist2,N,K,medianDist2,G2,index,Nind);

//			createKNNGraph(dist1,N,K,medianDist1,G1);
//			createKNNGraph(dist2,N,K,medianDist2,G2);
/*			n=0;
			for (i=0;i<N;i++)
			{
				s=0;
				
				for (j=0;j<N;j++)
				{
					s+=(int(G1[i*N+j]+G11[i*N+j])%2)+(int(G2[i*N+j]+G22[i*N+j])%2)	;				
				}
				if(s>0)
					ind[n++]=i;
			}*/	
			Nind=0;
			for (ii=0;ii<N;ii++)
			{
				x1[ii]+=x2[ii];
			}
			findIndex(x1,N,index,&Nind);
			createWeightedGraph(G1,G2,N,P1,P2,index,Nind,G3);
		
		
		}
		maxArr(G3,N*N,&s,&k);	
		num++;
		if(num>N)
			e=1;

//		cout<<num<<endl;
		if (s<angDist && fabs(mu1-mu2)<ebs)
			e=1;
		mu1=mu2;
		s=0;
		for (ii=0;ii<N;ii++)
		{
			if(outliers[ii]==0)
				s++;
		}
		if(s<3)
		{
			for (ii=0;ii<N;ii++)
				outliers[ii]=1;
		
			e=1;
		}

	
	}
//	cout<<num++<<endl;
	free(dist1);
	free(dist2);
	free(dist3);
	free(G1);
	free(G2);
	free(G11);
	free(G22);
	free(G3);
	free(temp);
	free(x);
	free (x1);
	free(x2);
	free(ind);
	free(index);
	free(ind1);

}
void findIndex(double x[],int N,int y[], int *Ny)
{
	int i;
	*Ny=0;
	for(i=0;i<N;i++)
	{
		if(x[i]!=0)
		{
			y[(*Ny)++]=i;
		}
	}
}
//
void createKNNGraph(double dist[],int N, int K,double medianDist, double G[])
{
	int i,j,k,n;
	double *x,*y,m;

	x = (double*)calloc(N,sizeof(double));
	y = (double*)calloc(N,sizeof(double));
	
	for (i=0;i<N*N;i++)
	{
		G[i]=0;
	}
	
	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			x[j]=dist[i*N+j];
		}
		k=0;
		
		while (k<K)
		{
			minArr(x,N,&m,&n);
			if (m>medianDist)
				k=K;
			else
			{
				G[i*N+n]=1;
				x[n]=medianDist;			
				k++;
			}

		}

	}
	for (i=0;i<N;i++)
	{
		for (j=i;j<N;j++)
		{
			if (G[i*N+j]==1 || G[j*N+i]==1)
			{
				G[i*N+j]=1;
				G[j*N+i]=1;
			}
		}
	}
	
	free(x);
	free(y);
}
void createKNNGraph_WGTM(double dist[],int N, int K,double medianDist, double G[])
{
	int i,j,k,n;
	double *x,*y,m;
	
	x = (double*)calloc(N,sizeof(double));
	y = (double*)calloc(N,sizeof(double));
	
	for (i=0;i<N*N;i++)
	{
		G[i]=0;
	}
	
	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			x[j]=dist[i*N+j];
		}
		k=0;
		
		while (k<K)
		{
			minArr(x,N,&m,&n);
			if (m>medianDist)
				k=K;
			else
			{
				G[i*N+n]=1;
				x[n]=medianDist;			
				k++;
			}

		}

	}
	free(x);
	free(y);
	
}
void createKNNGraph_GTM(double dist[],int N, int K,double medianDist, double G[])
{
	int i,j,k,flag=0,n;
	double *x,*y,*dist1,m;

	x = (double*)calloc(N,sizeof(double));
	y = (double*)calloc(N,sizeof(double));
	dist1 = (double*)calloc(N*N,sizeof(double));

	for (i=0;i<N*N;i++)
	{
		G[i]=0;
	}
		copyArr(dist,dist1,N*N);
	while(flag==0)
	{
		flag=1;
		for(i=0;i<N;i++)
		{		
			k=0;
			for (j=0;j<N;j++)
			{
				if (dist1[i*N+j]<=medianDist)
					k++;
			}
			if(k<K&& k>0)
			{
				flag=0;
				for (j=0;j<N;j++)
				{
					dist1[i*N+j]=medianDist+1;
					dist1[j*N+i]=medianDist+1;
				}
			
			}

		}
	}

	for (i=0;i<N;i++)
	{
		for (j=0;j<N;j++)
		{
			x[j]=dist1[i*N+j];
		}
		k=0;

		
		while (k<K)
		{
			minArr(x,N,&m,&n);
			if (m>medianDist)
				k=K;
			else
			{
				G[i*N+n]=1;
				G[n*N+i]=1;
				x[n]=medianDist;			
				k++;
			}

		}

	}
/*	for (i=0;i<N;i++)
	{
		for (j=i;j<N;j++)
		{
			if (G[i*N+j]==1 || G[j*N+i]==1)
			{
				G[i*N+j]=1;
				G[j*N+i]=1;
			}
		}
	}*/
		
	free(x);
	free(y);
	free(dist1);
}
void createKNNGraph_fast_WGTM(double dist[],int N, int K,double medianDist, double G[],int ind[],int Nind )
{
	int i,j,k,ii,n;
	double *x,*y,m;

	x = (double*)calloc(N,sizeof(double));
	y = (double*)calloc(N,sizeof(double));

	
	for (ii=0;ii<Nind;ii++)
	{
		i=ind[ii];

		for (j=0;j<N;j++)
		{
			G[i*N+j]=0;
			x[j]=dist[i*N+j];
		}
		k=0;
		
		while (k<K)
		{
			minArr(x,N,&m,&n);
			if (m>medianDist)
				k=K;
			else
			{
				G[i*N+n]=1;
	
				x[n]=medianDist;			
				k++;
			}

		}

	}
	free(x);
	free(y);
}
void createKNNGraph_fast_GTM(double dist[],int N, int K,double medianDist, double G[],int ind[],int &Nind )
{
	int i,j,k,ii,flag=0,n;
	double *x,*y,*dist1,m;
	
	x = (double*)calloc(N,sizeof(double));
	y = (double*)calloc(N,sizeof(double));
	dist1 = (double*)calloc(N*N,sizeof(double));

	
	copyArr(dist,dist1,N*N);
	while(flag==0)
	{
		flag=1;
		for(i=0;i<N;i++)
		{		
			k=0;
			for (j=0;j<N;j++)
			{
				if (dist1[i*N+j]<=medianDist)
					k++;
			}
			if(k<K&& k>0)
			{
				flag=0;
				for (j=0;j<N;j++)
				{
					if (G[i*N+j]!=0)
					{
						ii=IsMember(ind,Nind,j);
						if (ii==0)
							ind[Nind++]=j;

					}
					dist1[i*N+j]=medianDist+1;
					dist1[j*N+i]=medianDist+1;
					G[i*N+j]=0;
					G[j*N+i]=0;
					
				}
			
			}

		}
	}
	
	for (ii=0;ii<Nind;ii++)
	{
		i=ind[ii];

		for (j=0;j<N;j++)
		{
			G[i*N+j]=0;
			G[i*N+j]=G[j*N+i];
			x[j]=dist1[i*N+j];
		}
		k=0;
		
		while (k<K)
		{
			minArr(x,N,&m,&n);
			if (m>medianDist)
				k=K;
			else
			{
				if(n==11)
					n=n;
				G[i*N+n]=1;
				G[n*N+i]=1;
				x[n]=medianDist;			
				k++;
			}

		}

	}
	free(x);
	free(y);
	free(dist1);
}
void createWeightedGraph(double G1[],double G2[],int N,double **P1,double **P2,int ind[], int Nind, double G3[])
{

	double *t,**r1,**r2,nn1,nn2;
	int i,j,k,n1,n2,n3,*ind1,*ind2;

	t = (double*)calloc(N,sizeof(double));
	ind1 = (int*)calloc(N,sizeof(int));
	ind2 = (int*)calloc(N,sizeof(int));
	r1 = (double**)calloc(N,sizeof(double*));
	r2 = (double**)calloc(N,sizeof(double*));

	for(i=0;i<N;i++)
	{
		r1[i] = (double*)calloc(2,sizeof(double));
		r2[i] = (double*)calloc(2,sizeof(double));
	}

	for (j=0;j<Nind;j++)
	{
		i=ind[j];
		for (k=0;k<N;k++)
			G3[i*N+k]=-1;
		n1=0;
		n2=0;
		for (k=0;k<N;k++)
		{
			if(G1[i*N+k]>0 && i!=k)
			{
				ind1[n1++]=k;
				if (G2[i*N+k]==0)
				{
					ind2[n2++]=n1-1;
				}
			}
		}
		if (n1>0)
		{
			n3=0;
			for (k=0;k<n1;k++)
			{
				r1[k][0]=P1[ind1[k]][0]-P1[i][0];
				r1[k][1]=P1[ind1[k]][1]-P1[i][1];
				r2[k][0]=P2[ind1[k]][0]-P2[i][0];
				r2[k][1]=P2[ind1[k]][1]-P2[i][1];
			}

			getAngularDistance(r1,r2,n1,t);
			nn1=n1;
			nn2=n2;
			if ((nn2)/nn1>.5)
			{
				for (k=0;k<n2;k++)
					t[ind2[k]]=3.14;
			}
			for (k=0;k<n1;k++)
			{
				G3[i*N+ind1[k]]=t[k];
			}

		}

	}
	free(t);
	free(ind1);
	free(ind2);
	for(i=0;i<N;i++)
	{
		free(r1[i]);
		free(r2[i]);
	}
	free(r1);
	free(r2);
}
void getAngularDistance(double **r1,double **r2,int N, double t[])
{
	int i,j,k,ind;
	double t1,**r3,*t2,*t3,m,a[2];

	
	t3 = (double*)calloc(N,sizeof(double));
	t2 = (double*)calloc(N*N,sizeof(double));
	r3 = (double**)calloc(N,sizeof(double*));
	for(i=0;i<N;i++)
		r3[i] = (double*)calloc(2,sizeof(double));

	for (i=0;i<N;i++)
		t[i]=0;
	for (j=0;j<N;j++)
	{
		m=(r1[j][0]*r2[j][0]+r1[j][1]*r2[j][1])/(sqrt(r1[j][0]*r1[j][0]+r1[j][1]*r1[j][1])*sqrt(r2[j][0]*r2[j][0]+r2[j][1]*r2[j][1]));
		if (m>0.99)
			t1=0;
		else
			t1=acos(m);

		 a[0]=r2[j][0]*cos(t1)+r2[j][1]*sin(t1);
		 a[1]=-r2[j][0]*sin(t1)+r2[j][1]*cos(t1);
	    if (abs(a[1]/a[0]-r1[j][1]/r1[j][0])>abs(a[0]/a[1]-r1[j][1]/r1[j][0]))
            t1=-t1;
        

		for (k=0;k<N;k++)
		{
			r3[k][0]=r2[k][0]*cos(t1)+r2[k][1]*sin(t1);
			r3[k][1]=-r2[k][0]*sin(t1)+r2[k][1]*cos(t1);
		}
		for (i=0;i<N;i++)
		{
			m=(r1[i][0]*r3[i][0]+r1[i][1]*r3[i][1])/(sqrt(r1[i][0]*r1[i][0]+r1[i][1]*r1[i][1])*sqrt(r3[i][0]*r3[i][0]+r3[i][1]*r3[i][1]));
			if (m>1)
				m=1;
			else if (m<-1)
				m=-1;

			t2[j*N+i]=fabs(acos(m));


		}




	}
	sumArr2(t2,N,t3,1);
	minArr(t3,N,&m,&ind);
	for (i=0;i<N;i++)
		t[i]=t2[ind*N+i];

	for(i=0;i<N;i++)
		free(r3[i]);

	free(r3);
	free(t2);
	free(t3);
}
int IsMember( int arr[], int N,int item )
{
	int flag=0;
	for(int i=0;i<N;i++)
	{
		if(arr[i]==item)
		{
			flag=1;
			i=N;
		}
	}
	return flag;
}
    
void selectionSort ( double arr[], int size) 
{ 
   int indexOfMin; 
   int pass; 
   int j; 
   double minValue;

   for ( pass = 0; pass < size - 1; pass++ ) 
   { 
           indexOfMin = pass; 
		   minValue=arr[pass];
           for ( j = pass + 1; j < size; j++ ) 
		   {
               if ( arr[j] <  minValue)
			   {
                   indexOfMin = j; 
				   minValue=arr[indexOfMin];
			   }
		   }

           swap ( &arr[pass], &arr[indexOfMin] ); 
   } 
} 

void swap ( double *x, double *y ) 
{ 
   double temp; 
   temp = *x; 
   *x = *y; 
   *y = temp; 
} 

void copyArr(double arr1[],double arr2[], int N)
{
	long int i;
	for (i=0;i<N;i++)
	{
		arr2[i]=arr1[i];
	}
}
void sumArr2(double arr1[], int N,double arr2[],int horz)
{
	int i,j;
	double s=0;
	if (horz==0)
	{
		for (i=0;i<N;i++)
		{
			s=0;
			for (j=0;j<N;j++)
			{
				s+=arr1[i+j*N];
			}
			arr2[i]=s;

		}
	}else
	{
		for (i=0;i<N;i++)
		{
			s=0;
			for (j=0;j<N;j++)
			{
				s+=arr1[i*N+j];
			}
			arr2[i]=s;
		}

	}
}
void maxArr2(double arr1[], int N,double arr2[],int horz)
{
	double s=0,*temp;
	int k,i,j;
	
	temp = (double*)calloc(N,sizeof(double));
	if (horz==0)
	{
		for (i=0;i<N;i++)
		{
			
			for (j=0;j<N;j++)
			{
				temp[j]=arr1[i+j*N];
			}
			maxArr(temp,N,&arr2[i],&k);

		}
	}else
	{
		for (i=0;i<N;i++)
		{
			s=0;
			for (j=0;j<N;j++)
			{
				temp[j]=arr1[i*N+j];
			}
			maxArr(temp,N,&arr2[i],&k);
		}

	}
	free(temp);

}
void maxArr(double arr1[], int N,double *m,int *ind)
{
	int i;
	*m=arr1[0];
	*ind=0;
	for (i=0;i<N;i++)
		if ((*m)<arr1[i])
		{
			*m=arr1[i];
			*ind=i;
		}
}
void minArr(double arr1[], int N,double *m,int *ind)
{
	int i;
	*m=arr1[0];
	*ind=0;
	for (i=0;i<N;i++)
		if ((*m)>arr1[i])
		{
			*m=arr1[i];
			*ind=i;
		}
}

